@echo off
cd /d "%~dp0"
call build.bat
if errorlevel 1 exit /b 1
start "LogisticsFlow Server" /D "%~dp0" logistics_server.exe
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:5000
