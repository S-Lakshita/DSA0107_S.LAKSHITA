@echo off
setlocal
cd /d "%~dp0"
if not exist include mkdir include
if not exist src mkdir src
if not exist web mkdir web
if not exist data mkdir data
where g++ >nul 2>nul
if errorlevel 1 (
  echo ERROR: g++ was not found. Install MinGW-w64 GCC and add its bin folder to PATH.
  pause
  exit /b 1
)
echo Building C++ logistics server...
g++ -std=c++17 -O2 -Wall -Wextra -Wpedantic -I include src\server.cpp src\storage.cpp src\scheduler.cpp -o logistics_server.exe -lws2_32
if errorlevel 1 (
  echo Build failed. Review the compiler messages above.
  pause
  exit /b 1
)
echo Build successful: logistics_server.exe
endlocal
