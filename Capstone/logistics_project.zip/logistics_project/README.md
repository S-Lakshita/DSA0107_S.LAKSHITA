# Deadline-Aware Logistics Scheduling & Delivery Performance Evaluation

A complete local logistics management web application. The backend, shipment validation, CSV persistence, scheduling algorithms, rescheduling logic and performance calculations are implemented in **C++17**. The frontend uses HTML, CSS and JavaScript. No Python backend, database server, CMake or third-party C++ library is required.

## 1. Requirements (Windows)

1. Install **Visual Studio Code**.
2. Install **MSYS2 / MinGW-w64 GCC** (64-bit UCRT toolchain). In the MSYS2 UCRT64 terminal run:

   ```bash
   pacman -S --needed mingw-w64-ucrt-x86_64-gcc
   ```

3. Add `C:\msys64\ucrt64\bin` to the Windows `PATH` (or open the UCRT64 terminal to build and run).
4. Verify the compiler in Windows Terminal / VS Code terminal:

   ```powershell
   g++ --version
   ```

The C++ application uses only the standard library and Windows Winsock (`ws2_32`, included with Windows). Chart.js and Google Fonts are optional CDN enhancements; the core dashboard and backend do not depend on them.

## 2. Open and run

Extract the ZIP, open the `logistics_project` folder in VS Code, then open its terminal.

**Build:**

```powershell
 g++ -std=c++17 -O2 -Wall -Wextra -Wpedantic -I include src\server.cpp src\storage.cpp src\scheduler.cpp -o logistics_server.exe -lws2_32
```

Or run the included build script:

```powershell
.\build.bat
```

**Start the server:**

```powershell
.\logistics_server.exe
```

Or use:

```powershell
.\run.bat
```

Open this address in Chrome or another browser:

**http://127.0.0.1:5000**

Keep the terminal window open while using the application. Press `Ctrl+C` in that window to stop the server. Run the server from the project root so the `web` and `data` folders are found correctly.

`start.bat` builds the application, starts the server and opens the dashboard in the default browser.

## 3. Project structure

```text
logistics_project/
├── .vscode/
│   └── tasks.json
├── data/
│   ├── .gitkeep
│   ├── shipments.csv      # Created after first shipment save
│   └── history.csv        # Created after first recorded event
├── include/
│   ├── json.hpp          # Small JSON request/response helpers
│   ├── models.hpp        # Shipment, Vehicle, Driver and history models
│   ├── scheduler.hpp     # Scheduling interface
│   └── storage.hpp       # CSV persistence interface
├── src/
│   ├── scheduler.cpp     # FCFS, EDF, priority and Greedy scheduling
│   ├── server.cpp        # C++ HTTP server and REST API
│   └── storage.cpp       # CSV read/write implementation
├── web/
│   ├── app.js            # Dashboard interactions and API calls
│   ├── index.html        # Four-module dashboard
│   └── style.css         # Responsive dashboard styling
├── build.bat
├── run.bat
├── start.bat
└── README.md
```

## 4. The four connected modules

### MODULE 1: SHIPMENT ORDER & DEADLINE MANAGEMENT

- Create, validate, edit, search, filter and delete shipment orders.
- Fields: order ID, delivery location, package weight, priority, deadline, distance, estimated travel time and delivery status.
- Duplicate IDs are rejected. Numeric values and allowed status/priority values are validated in C++.
- Completed deliveries are protected from edits and deletion.
- `Shipment` includes `validate()`, `updateStatus()` and `estimateArrival()` methods.
- Orders are held in `std::vector<Shipment>` and persisted to `data/shipments.csv`.

### MODULE 2: JOB SEQUENCING-BASED SCHEDULING

- FCFS, Earliest Deadline First (EDF), priority-based and Greedy feasible selection.
- Uses `std::vector`, `std::sort` and `std::priority_queue`.
- `Vehicle` and `Driver` models provide capacity and availability constraints.
- Feasibility checks package weight against vehicle capacity, driver availability and cumulative travel-time against each deadline.
- Run a selected algorithm to create a schedule, or compare all four algorithms.

### MODULE 3: DYNAMIC RESCHEDULING & DELAY MANAGEMENT

- Traffic delay: increases estimated travel time by the selected multiplier.
- Vehicle breakdown/restoration: changes available vehicle capacity.
- Driver unavailable/available: updates driver state.
- New urgent shipment: inserts a high-priority shipment into the pending queue.
- Recalculates an EDF-based schedule, marks affected orders and records events in the audit history.
- Completed shipments are never changed by rescheduling.

### MODULE 4: PERFORMANCE EVALUATION & REPORTS

- On-time delivery rate, late shipment count, average lateness, total delivery time, completed shipments, orders at risk and scheduling efficiency.
- Side-by-side FCFS, EDF, priority and Greedy comparison.
- Dashboard charts and CSV export (`/api/export`).

## 5. API routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/shipments` | List shipment orders |
| POST | `/api/shipments` | Register shipment |
| PUT | `/api/shipments/{id}` | Update shipment |
| DELETE | `/api/shipments/{id}` | Delete non-completed shipment |
| GET | `/api/schedule/compare` | Compare four scheduling algorithms |
| POST | `/api/schedule` | Generate a selected schedule |
| POST | `/api/reschedule` | Apply an event and recalculate schedule |
| POST | `/api/complete` | Mark a shipment completed |
| GET | `/api/metrics` | Get delivery performance metrics |
| GET | `/api/history` | Get shipment/delay history |
| GET | `/api/state` | Get vehicle and driver state |
| GET | `/api/export` | Download shipment report as CSV |

## 6. Data and scheduling assumptions

- The CSV file is created automatically on the first save. It is the persistent source of shipment records; no separate database installation is needed.
- Enter a deadline as `HH:MM` (24-hour time) or `YYYY-MM-DD HH:MM`. The scheduler evaluates the clock portion as a planning-day deadline and accumulates travel durations in hours from hour zero.
- Each shipment's package weight must fit the configured vehicle capacity. The single-driver schedule accumulates travel time in sequence order.
- A shipment is counted as completed when the operator uses the completion action. Its entered actual delivery duration is used for delivery performance calculations.
- Shipment records and the shipment/delay audit history persist in separate CSV files across restarts (`data/shipments.csv` and `data/history.csv`).
- Chart.js is loaded from a CDN when internet access is available. Without internet, the tables and all backend features still work; chart areas show an offline notice.

## 7. Troubleshooting

- **`g++ is not recognized`:** add the MSYS2 UCRT64 `bin` folder to `PATH`, reopen the terminal and run `g++ --version`.
- **Port 5000 is already in use:** stop the other application using port 5000, then restart this server.
- **Dashboard cannot load data:** ensure the server is running and that it was launched from the project root folder.
- **CSV data not visible:** check `data/shipments.csv` and `data/history.csv`; the server creates them automatically when data is first saved.

## 8. Build without a CMake project

This project intentionally uses a direct GCC command and the provided `.bat` scripts. There is no CMake configuration or Python server.
