#pragma once
#include <string>
#include <map>
#include <regex>
#include <sstream>
#include <iomanip>
inline std::string jsonEscape(const std::string& s){std::ostringstream o; for(unsigned char c:s){switch(c){case '"':o<<"\\\"";break;case '\\':o<<"\\\\";break;case '\n':o<<"\\n";break;case '\r':o<<"\\r";break;case '\t':o<<"\\t";break;default: if(c<32)o<<" ";else o<<c;}}return o.str();}
inline std::string jstr(const std::string& s){return "\""+jsonEscape(s)+"\"";}
inline std::string jnum(double n){std::ostringstream o;o<<std::fixed<<std::setprecision(2)<<n;return o.str();}
inline std::map<std::string,std::string> parseObject(const std::string& s){std::map<std::string,std::string> m; std::regex r("\\\"([^\\\"]+)\\\"\\s*:\\s*(\\\"(?:\\\\.|[^\\\"])*\\\"|[^,}\\s]+)"); for(std::sregex_iterator i(s.begin(),s.end(),r),e;i!=e;++i){std::string v=(*i)[2]; if(v.size()>=2&&v.front()=='"'){v=v.substr(1,v.size()-2);std::string out;for(size_t k=0;k<v.size();++k){if(v[k]=='\\'&&k+1<v.size()){char c=v[++k];if(c=='n')out+='\n';else if(c=='r')out+='\r';else if(c=='t')out+='\t';else out+=c;}else out+=v[k];}v=out;}m[(*i)[1]]=v;}return m;}
inline std::string getv(const std::map<std::string,std::string>& m,const std::string& k,const std::string& d=""){auto i=m.find(k);return i==m.end()?d:i->second;}
inline double getd(const std::map<std::string,std::string>& m,const std::string& k,double d=0){try{return std::stod(getv(m,k));}catch(...){return d;}}
