#pragma once
#include "models.hpp"
#include <string>
#include <vector>
struct ScheduleResult { std::string algorithm; std::vector<std::string> sequence; int feasible=0, rejected=0; double totalTime=0, efficiency=0; };
class Scheduler { public: static ScheduleResult run(const std::vector<Shipment>&,const std::string&,double capacity=1000,bool driverAvailable=true); static std::vector<ScheduleResult> compare(const std::vector<Shipment>&,double capacity=1000,bool driverAvailable=true); };
