#pragma once
#include "models.hpp"
#include <string>
#include <vector>
class Storage { std::string file; public: explicit Storage(std::string f):file(std::move(f)){} std::vector<Shipment> load(); void save(const std::vector<Shipment>&); };
class HistoryStorage { std::string file; public: explicit HistoryStorage(std::string f):file(std::move(f)){} std::vector<HistoryEntry> load(); void save(const std::vector<HistoryEntry>&); };
