#pragma once
#include <string>
#include <vector>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <algorithm>

struct Shipment {
    std::string id, location, priority, deadline, status;
    double weight=0, distance=0, travelTime=0, actualDeliveryTime=0;
    std::string createdAt;
    bool validate(std::string& error) const {
        if(id.empty()||location.empty()||deadline.empty()) { error="Order ID, delivery location and deadline are required."; return false; }
        if(weight<=0||distance<0||travelTime<=0) { error="Weight and travel time must be positive; distance cannot be negative."; return false; }
        if(priority!="High"&&priority!="Medium"&&priority!="Low") { error="Priority must be High, Medium or Low."; return false; }
        if(status!="Pending"&&status!="Scheduled"&&status!="In Transit"&&status!="Completed"&&status!="Delayed") { error="Invalid delivery status."; return false; }
        return true;
    }
    void updateStatus(const std::string& s) { if(status!="Completed") status=s; }
    double estimateArrival(double startHour=0) const { return startHour+travelTime; }
};
struct Vehicle { std::string id="V-01"; double capacity=1000; bool available=true; };
struct Driver { std::string id="D-01"; bool available=true; };
struct HistoryEntry { std::string time, shipmentId, event, detail; };
inline std::string nowString(){ std::time_t t=std::time(nullptr); std::tm tm{}; if(const std::tm* value=std::localtime(&t)) tm=*value;
 std::ostringstream o; o<<std::put_time(&tm,"%Y-%m-%d %H:%M:%S"); return o.str(); }
inline int priorityRank(const std::string& p){return p=="High"?0:p=="Medium"?1:2;}
