# Build and functional verification

Verification performed while assembling this project:

- C++17 build completed successfully with `-Wall -Wextra -Wpedantic` and no compiler warnings in the available GCC environment.
- Frontend JavaScript syntax check completed successfully with Node.js.
- Local HTTP smoke tests passed for the dashboard, shipment create/update/delete, algorithm comparison, schedule generation, capacity rejection, traffic delay, vehicle breakdown/restoration, driver availability changes, urgent shipment arrival, delivery completion, completed-order protection, history, metrics and CSV export.
- Shipment and history CSV data were removed after testing so the delivered project starts with a clean register and audit log.

The application is configured for Windows MinGW-w64 and links Winsock using `-lws2_32`. A Windows-native MinGW compile could not be executed in the Linux build environment; use the included `build.bat` on the target Windows installation.
