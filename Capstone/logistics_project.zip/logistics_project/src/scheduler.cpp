#include "scheduler.hpp"
#include <algorithm>
#include <queue>
static double deadlineHour(const std::string& s){try{size_t pos=s.size()>=16?11:0;int h=std::stoi(s.substr(pos,2));int m=std::stoi(s.substr(pos+3,2));return h+m/60.0;}catch(...){return 24.0;}}
ScheduleResult Scheduler::run(const std::vector<Shipment>& all,const std::string& alg,double capacity,bool driverAvailable){ScheduleResult r;r.algorithm=alg;std::vector<Shipment> p;for(auto&s:all)if(s.status!="Completed")p.push_back(s);
 if(alg=="EDF")std::sort(p.begin(),p.end(),[](auto&a,auto&b){return a.deadline<b.deadline;});
 else if(alg=="Priority")std::sort(p.begin(),p.end(),[](auto&a,auto&b){if(priorityRank(a.priority)!=priorityRank(b.priority))return priorityRank(a.priority)<priorityRank(b.priority);return a.deadline<b.deadline;});
 else if(alg=="Greedy"){std::priority_queue<std::pair<double,size_t>,std::vector<std::pair<double,size_t>>,std::greater<std::pair<double,size_t>>> q;for(size_t i=0;i<p.size();++i){double slack=std::max(0.0,24.0-p[i].travelTime);q.push({slack,i});}std::vector<Shipment>x;while(!q.empty()){x.push_back(p[q.top().second]);q.pop();}p=x;}
 else std::sort(p.begin(),p.end(),[](auto&a,auto&b){return a.createdAt<b.createdAt;});
 Vehicle vehicle; vehicle.capacity=capacity; Driver driver; driver.available=driverAvailable; double clock=0;for(auto&s:p){bool ok=driver.available&&s.weight<=vehicle.capacity&&s.estimateArrival(clock)<=deadlineHour(s.deadline); if(ok){r.sequence.push_back(s.id);clock+=s.travelTime;r.totalTime+=s.travelTime;++r.feasible;}else ++r.rejected;}r.efficiency=p.empty()?0:100.0*r.feasible/p.size();return r;}
std::vector<ScheduleResult> Scheduler::compare(const std::vector<Shipment>& s,double capacity,bool driverAvailable){std::vector<Shipment> sample=s;for(auto& x:sample)if(x.status=="Completed")x.status="Pending";return {run(sample,"FCFS",capacity,driverAvailable),run(sample,"EDF",capacity,driverAvailable),run(sample,"Priority",capacity,driverAvailable),run(sample,"Greedy",capacity,driverAvailable)};}
