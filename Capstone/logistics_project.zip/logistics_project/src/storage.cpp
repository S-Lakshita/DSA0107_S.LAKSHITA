#include "storage.hpp"
#include <fstream>
#include <sstream>
static std::string csv(const std::string& s){std::string x="\"";for(char c:s){if(c=='\"')x+="\"\"";else x+=c;}return x+"\"";}
static std::vector<std::string> splitCsv(const std::string& line){std::vector<std::string> a;std::string x;bool q=false;for(size_t i=0;i<line.size();++i){char c=line[i];if(c=='\"'){if(q&&i+1<line.size()&&line[i+1]=='\"'){x+='\"';++i;}else q=!q;}else if(c==','&&!q){a.push_back(x);x.clear();}else x+=c;}a.push_back(x);return a;}
std::vector<Shipment> Storage::load(){std::vector<Shipment> v;std::ifstream in(file);std::string line;if(!in)return v;std::getline(in,line);while(std::getline(in,line)){auto a=splitCsv(line);if(a.size()<10)continue;try{Shipment s;s.id=a[0];s.location=a[1];s.weight=std::stod(a[2]);s.priority=a[3];s.deadline=a[4];s.distance=std::stod(a[5]);s.travelTime=std::stod(a[6]);s.status=a[7];s.actualDeliveryTime=std::stod(a[8]);s.createdAt=a[9];v.push_back(s);}catch(...){}}return v;}
void Storage::save(const std::vector<Shipment>& v){std::ofstream o(file,std::ios::trunc);o<<"id,location,weight,priority,deadline,distance,travel_time,status,actual_delivery_time,created_at\n";for(auto&s:v)o<<csv(s.id)<<','<<csv(s.location)<<','<<s.weight<<','<<csv(s.priority)<<','<<csv(s.deadline)<<','<<s.distance<<','<<s.travelTime<<','<<csv(s.status)<<','<<s.actualDeliveryTime<<','<<csv(s.createdAt)<<'\n';}

std::vector<HistoryEntry> HistoryStorage::load(){std::vector<HistoryEntry> v;std::ifstream in(file);std::string line;if(!in)return v;std::getline(in,line);while(std::getline(in,line)){auto a=splitCsv(line);if(a.size()<4)continue;HistoryEntry h;h.time=a[0];h.shipmentId=a[1];h.event=a[2];h.detail=a[3];v.push_back(h);}return v;}
void HistoryStorage::save(const std::vector<HistoryEntry>& v){std::ofstream o(file,std::ios::trunc);o<<"time,shipment_id,event,detail\n";for(auto&h:v)o<<csv(h.time)<<','<<csv(h.shipmentId)<<','<<csv(h.event)<<','<<csv(h.detail)<<'\n';}
