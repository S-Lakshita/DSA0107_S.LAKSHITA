@echo off
cd /d "%~dp0"
if not exist logistics_server.exe (
  call build.bat
  if errorlevel 1 exit /b 1
)
logistics_server.exe
